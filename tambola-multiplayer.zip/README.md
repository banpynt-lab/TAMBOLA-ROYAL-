# 🎱 Tambola Royale — Multiplayer

Real-time multiplayer Tambola / Housie built with Node.js + Socket.io.

## Quick Start

### 1. Install dependencies
```bash
npm install
```

### 2. Start the server
```bash
node server.js
```

### 3. Open in browser
```
http://localhost:3000
```

### 4. Share with friends on the same WiFi / internet
- Get your PC's local IP: run `ipconfig` (Windows) or `ifconfig` (Mac/Linux)
- Share `http://YOUR_IP:3000` with friends on the same network
- For internet play: deploy to Railway, Render, or Fly.io (free tier)

---

## How to Play

1. **Host** enters their name → clicks **Create New Room**
2. **Host** shares the 6-character room code (tap it to copy)
3. **Players** enter their name + room code → click **Join Room**
4. **Host** clicks **▶ Start Game** when everyone is ready
5. **Host** calls numbers manually or uses **⚡ Auto Call**
6. Numbers are **auto-marked** on every player's ticket
7. First player to complete Early 5 / Top Row / Middle Row / Full House wins!

---

## Features

| Feature | Detail |
|---|---|
| Real-time sync | Socket.io, <50ms latency on LAN |
| Room codes | 6-character codes (e.g. `A3F9C1`) |
| Rejoin protection | Disconnect & reconnect by name — keep your ticket |
| Host controls | Start, Pause, Resume, End, Manual call, Auto-call |
| Auto-call speed | Adjustable 1.5s – 8s per number |
| Win detection | Early 5, Top Row, Middle Row, Full House |
| Live leaderboard | See all players' marked count in real time |
| In-game chat | Full chat with host crown indicator |
| Cheat protection | Server-side mark validation |
| Mobile optimized | Portrait-first, no overlapping numbers |

---

## Deploy to the Internet (free)

### Railway (easiest)
```bash
npm install -g railway
railway login
railway init
railway up
```

### Render
1. Push to GitHub
2. Go to render.com → New Web Service
3. Connect your repo → Build: `npm install`, Start: `node server.js`
4. Done — Render gives you a public URL
