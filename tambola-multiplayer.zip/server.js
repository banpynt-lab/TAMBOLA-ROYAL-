/**
 * TAMBOLA ROYALE — Multiplayer Server
 * Socket.io + Express  |  node server.js
 */
const express  = require('express');
const http     = require('http');
const { Server } = require('socket.io');
const path     = require('path');
const crypto   = require('crypto');

const app    = express();
const server = http.createServer(app);
const io     = new Server(server, {
  cors: { origin: '*', methods: ['GET','POST'] },
  pingTimeout: 20000, pingInterval: 10000,
});
app.use(express.static(path.join(__dirname, 'public')));

// ── ROOM STORE ───────────────────────────────────────────
const rooms = new Map();

// ── HELPERS ──────────────────────────────────────────────
const makeCode = () => crypto.randomBytes(3).toString('hex').toUpperCase();
const range    = (lo, hi) => Array.from({ length: hi-lo+1 }, (_,i) => lo+i);
function shuffle(arr) {
  const a = [...arr];
  for (let i=a.length-1; i>0; i--) { const j=Math.floor(Math.random()*(i+1)); [a[i],a[j]]=[a[j],a[i]]; }
  return a;
}

// ── TICKET GENERATION ────────────────────────────────────
const COL_RANGES = [[1,9],[10,19],[20,29],[30,39],[40,49],[50,59],[60,69],[70,79],[80,90]];
function generateTicket() {
  for (let attempt=0; attempt<300; attempt++) { const t=tryGen(); if(t) return t; }
  return null;
}
function tryGen() {
  const grid   = Array.from({length:3}, ()=>new Array(9).fill(0));
  const rowCnt = [0,0,0];
  for (let ci=0; ci<9; ci++) {
    const [lo,hi] = COL_RANGES[ci];
    const pool  = shuffle(range(lo,hi));
    const elig  = [0,1,2].filter(ri=>rowCnt[ri]<5);
    if (!elig.length) continue;
    const want   = Math.min(elig.length, pool.length, (ci>=3&&elig.length>=2&&Math.random()<0.38)?2:1);
    shuffle([...elig]).slice(0,want).forEach((ri,i)=>{ grid[ri][ci]=pool[i]; rowCnt[ri]++; });
  }
  for (let ri=0; ri<3; ri++) {
    let s=0;
    while (rowCnt[ri]<5 && s++<25) {
      const cands=[];
      for (let ci=0; ci<9; ci++) {
        if (grid[ri][ci]!==0) continue;
        const [lo,hi]=COL_RANGES[ci];
        const used=new Set([grid[0][ci],grid[1][ci],grid[2][ci]].filter(Boolean));
        const p=range(lo,hi).filter(n=>!used.has(n));
        if (p.length) cands.push({ci,p});
      }
      if (!cands.length) return null;
      const {ci,p}=cands[Math.floor(Math.random()*cands.length)];
      grid[ri][ci]=p[Math.floor(Math.random()*p.length)]; rowCnt[ri]++;
    }
  }
  const flat=grid.flat().filter(Boolean);
  if (flat.length!==15||new Set(flat).size!==15||rowCnt.some(c=>c!==5)) return null;
  return grid;
}

// ── SNAPSHOT ─────────────────────────────────────────────
function snap(room) {
  return {
    code: room.code, hostId: room.hostId, hostName: room.hostName,
    status: room.status, called: room.called,
    players: [...room.players.values()].map(p=>({
      id: p.id, name: p.name, connected: p.connected,
      markedCount: [...p.marked].filter(n=>p.ticketGrid.flat().includes(n)).length,
    })),
  };
}

// ── WIN CHECK ─────────────────────────────────────────────
function checkWins(room, player) {
  const {ticketGrid:grid, marked, id, name} = player;
  const nums  = grid.flat().filter(Boolean);
  const events = [];
  const W = room.wins;
  if (!W.early5.has(id) && nums.filter(n=>marked.has(n)).length>=5) { W.early5.add(id); events.push({type:'early5',playerName:name}); }
  if (!W.topRow.has(id)) { const t=grid[0].filter(Boolean); if(t.length&&t.every(n=>marked.has(n))){ W.topRow.add(id); events.push({type:'topRow',playerName:name}); } }
  if (!W.midRow.has(id)) { const m=grid[1].filter(Boolean); if(m.length&&m.every(n=>marked.has(n))){ W.midRow.add(id); events.push({type:'midRow',playerName:name}); } }
  if (!W.full.has(id) && nums.length===15 && nums.every(n=>marked.has(n))) { W.full.add(id); events.push({type:'fullHouse',playerName:name}); }
  return events;
}

function broadcast(room) { io.to(room.code).emit('room:update', snap(room)); }
function stopAuto(room)  { if(room.autoTimer){ clearInterval(room.autoTimer); room.autoTimer=null; } }

function doCall(room) {
  if (!room.bag.length || room.status!=='playing') { stopAuto(room); return; }
  const idx = Math.floor(Math.random()*room.bag.length);
  const num  = room.bag.splice(idx,1)[0];
  room.called.push(num);
  const evts=[];
  room.players.forEach(p=>{ if(new Set(p.ticketGrid.flat().filter(Boolean)).has(num)){ p.marked.add(num); evts.push(...checkWins(room,p)); } });
  io.to(room.code).emit('game:number',{number:num,called:room.called,remaining:room.bag.length});
  evts.forEach(ev=>{ io.to(room.code).emit('game:win',ev); io.to(room.code).emit('chat',{system:true,text:winMsg(ev)}); });
  if (!room.bag.length) { stopAuto(room); io.to(room.code).emit('chat',{system:true,text:'All 90 numbers called!'}); }
}

const winMsg = ev => ({ early5:'⭐ Early 5', topRow:'🔷 Top Row', midRow:'🔴 Middle Row', fullHouse:'🏆 Full House' }[ev.type]||ev.type) + ` — ${ev.playerName}!`;

// ── SOCKETS ───────────────────────────────────────────────
io.on('connection', socket => {
  console.log(`[+] ${socket.id}`);

  socket.on('room:create', ({playerName}) => {
    const code   = makeCode();
    const ticket = generateTicket();
    if (!ticket) { socket.emit('error','Ticket generation failed.'); return; }
    const player = { id:socket.id, name:playerName, ticketGrid:ticket, marked:new Set(), connected:true };
    const room   = { code, hostId:socket.id, hostName:playerName,
      players:new Map([[socket.id,player]]),
      bag:shuffle(range(1,90)), called:[], status:'lobby', autoTimer:null,
      wins:{early5:new Set(),topRow:new Set(),midRow:new Set(),full:new Set()},
    };
    rooms.set(code, room);
    socket.join(code);
    socket.data.roomCode = code;
    socket.emit('room:joined',{room:snap(room),myTicket:ticket,isHost:true});
    console.log(`[ROOM] created ${code} by ${playerName}`);
  });

  socket.on('room:join', ({roomCode, playerName}) => {
    const code = roomCode.trim().toUpperCase();
    const room = rooms.get(code);
    if (!room)                    { socket.emit('error','Room not found.'); return; }
    if (room.status==='ended')    { socket.emit('error','Game already ended.'); return; }
    if (!playerName?.trim())      { socket.emit('error','Enter your name.'); return; }

    // Rejoin detection
    let rejoinPlayer = null;
    for (const p of room.players.values()) {
      if (p.name.toLowerCase()===playerName.trim().toLowerCase() && !p.connected) { rejoinPlayer=p; break; }
    }
    if (rejoinPlayer) {
      room.players.delete(rejoinPlayer.id);
      rejoinPlayer.id = socket.id; rejoinPlayer.connected = true;
      room.players.set(socket.id, rejoinPlayer);
      socket.join(code); socket.data.roomCode=code;
      socket.emit('room:joined',{room:snap(room),myTicket:rejoinPlayer.ticketGrid,isHost:false,isRejoin:true,calledSoFar:room.called,markedSoFar:[...rejoinPlayer.marked]});
      broadcast(room);
      io.to(code).emit('chat',{system:true,text:`${playerName} rejoined.`});
      return;
    }
    if (room.status==='playing')  { socket.emit('error','Game in progress. Cannot join now.'); return; }
    const ticket = generateTicket();
    if (!ticket) { socket.emit('error','Ticket generation failed.'); return; }
    const player = { id:socket.id, name:playerName.trim(), ticketGrid:ticket, marked:new Set(), connected:true };
    room.players.set(socket.id, player);
    socket.join(code); socket.data.roomCode=code;
    socket.emit('room:joined',{room:snap(room),myTicket:ticket,isHost:false,isRejoin:false,calledSoFar:[]});
    broadcast(room);
    io.to(code).emit('chat',{system:true,text:`${player.name} joined!`});
    console.log(`[ROOM] ${player.name} joined ${code}`);
  });

  socket.on('game:start', ()=>{
    const room=rooms.get(socket.data.roomCode);
    if (!room||socket.id!==room.hostId) return;
    room.status='playing'; broadcast(room);
    io.to(room.code).emit('game:started');
    io.to(room.code).emit('chat',{system:true,text:'🎱 Game started! Good luck everyone!'});
  });

  socket.on('game:pause', ()=>{
    const room=rooms.get(socket.data.roomCode);
    if (!room||socket.id!==room.hostId) return;
    if (room.status==='playing') { stopAuto(room); room.status='paused'; broadcast(room); io.to(room.code).emit('chat',{system:true,text:'Game paused.'}); }
    else if (room.status==='paused') { room.status='playing'; broadcast(room); io.to(room.code).emit('chat',{system:true,text:'Game resumed.'}); }
  });

  socket.on('game:end', ()=>{
    const room=rooms.get(socket.data.roomCode);
    if (!room||socket.id!==room.hostId) return;
    stopAuto(room); room.status='ended'; broadcast(room);
    io.to(room.code).emit('game:ended');
    io.to(room.code).emit('chat',{system:true,text:'Game ended by host.'});
  });

  socket.on('game:call', ()=>{
    const room=rooms.get(socket.data.roomCode);
    if (!room||socket.id!==room.hostId||room.status!=='playing') return;
    doCall(room);
  });

  socket.on('game:autoStart', ({intervalMs=2500})=>{
    const room=rooms.get(socket.data.roomCode);
    if (!room||socket.id!==room.hostId||room.status!=='playing') return;
    stopAuto(room);
    room.autoTimer=setInterval(()=>doCall(room), Math.max(1500,Math.min(10000,intervalMs)));
    socket.emit('game:autoOn');
  });

  socket.on('game:autoStop', ()=>{
    const room=rooms.get(socket.data.roomCode);
    if (!room||socket.id!==room.hostId) return;
    stopAuto(room); socket.emit('game:autoOff');
  });

  socket.on('game:mark', ({number})=>{
    const room=rooms.get(socket.data.roomCode);
    if (!room) return;
    const player=room.players.get(socket.id);
    if (!player||!room.called.includes(number)) return;
    if (player.marked.has(number)) player.marked.delete(number); else player.marked.add(number);
    const evts=checkWins(room,player);
    socket.emit('mark:ack',{number,marked:[...player.marked]});
    evts.forEach(ev=>{ io.to(room.code).emit('game:win',ev); io.to(room.code).emit('chat',{system:true,text:winMsg(ev)}); });
    broadcast(room);
  });

  socket.on('chat:send', ({text})=>{
    const room=rooms.get(socket.data.roomCode);
    if (!room) return;
    const player=room.players.get(socket.id);
    if (!player) return;
    const msg=text?.trim().slice(0,120);
    if (!msg) return;
    io.to(room.code).emit('chat',{name:player.name,text:msg,isHost:socket.id===room.hostId});
  });

  socket.on('disconnect', ()=>{
    console.log(`[-] ${socket.id}`);
    const room=rooms.get(socket.data?.roomCode);
    if (!room) return;
    const player=room.players.get(socket.id);
    if (player) { player.connected=false; broadcast(room); io.to(room.code).emit('chat',{system:true,text:`${player.name} disconnected.`}); }
    if (socket.id===room.hostId && room.status==='playing') {
      stopAuto(room); room.status='paused'; broadcast(room);
      io.to(room.code).emit('chat',{system:true,text:'Host disconnected — game paused.'});
    }
    setTimeout(()=>{
      const r=rooms.get(socket.data?.roomCode);
      if (r && [...r.players.values()].every(p=>!p.connected)) { stopAuto(r); rooms.delete(r.code); console.log(`[ROOM] cleaned ${r.code}`); }
    }, 600000);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, ()=> console.log(`\n🎱 Tambola Royale → http://localhost:${PORT}\n`));
